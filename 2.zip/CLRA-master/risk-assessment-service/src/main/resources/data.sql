insert into collateralmarketvalue(rate_id,rate_per_sqr_feet)values(1,6000);

insert into collateralinterestrate(interest_id,interest_rate)values(1,6.7);
insert into collateralinterestrate(interest_id,interest_rate)values(2,8.2);
insert into collateralinterestrate(interest_id,interest_rate)values(3,7.50);
insert into collateralinterestrate(interest_id,interest_rate)values(4,7.75);
insert into collateralinterestrate(interest_id,interest_rate)values(5,5.1);
insert into collateralinterestrate(interest_id,interest_rate)values(6,6.4);
insert into collateralinterestrate(interest_id,interest_rate)values(7,7.9);


