insert into user(id, name, password) values (1, 'admin1', 'abc1');
insert into user(id, name, password) values (2, 'admin2', 'abc2');
insert into user(id, name, password) values (3, 'admin3', 'abc3');




insert into customer(id,name,password) values (100011,'mahima', 'abc1');
insert into customer(id,name,password) values (100012,'adyasha', 'abc2');
insert into customer(id,name,password) values (100013,'vishal', 'abc3');
insert into customer(id,name,password) values (100014,'pradaap', 'abc4');
