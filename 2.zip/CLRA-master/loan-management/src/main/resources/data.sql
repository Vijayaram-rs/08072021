insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100001,'Abarna Chandrasekar','abarna@gmail.com','7343671178','Chennai');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100002,'Evan Varghese','evan@gmail.com','9985672342','Thiruvananthapuram');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100003,'Shalini Kandukuri','shalini@gmail.com','6378902343','Hyderabad');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100004,'Naveen Kumar Gowda','naveen@gmail.com','7458780121','Bangalore');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100005,'Iftikhar Ahmed','iftikhar@gmail.com','8709902343','New Delhi');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100006,'Mamta Basu','mamta@gmail.com','9874782121','Kolkata');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100007,'Kiran Bhatt','kiran@gmail.com','8678902343','Mumbai');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100008,'Mayur Jayadev','mayur@gmail.com','6678902343','Jaipur');

 

 

 


insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1001,'Home Loan',750000,6.7,35,'REAL_ESTATE');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1002,'Home Loan',100000,8.2,42,'CASH_DEPOSIT');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1003,'Car Loan',700000,7.50,30,'REAL_ESTATE');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1004,'Car Loan',500000,7.75,24,'CASH_DEPOSIT');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1005,'Education Loan',500000,5.1,26,'CASH_DEPOSIT');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1006,'Medical Loan',500000,6.4,18,'REAL_ESTATE');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1008,'Medical Loan',500000,7.9,27,'CASH_DEPOSIT');

 

 

 


