package com.cts.training.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity
@Table(name = "loanApplication")
public class LoanApplication {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@ApiModelProperty(value = "Id of the Loan Application")
	private Integer applicationId;
	
	@ApiModelProperty(value = "CustomerId in the LoanApplication")
	private Integer customerId;
	
	@ApiModelProperty(value = "Loan Amount")
	private Double loanAmount;
	
	@ApiModelProperty(value = "Tenure of the loan")
	private Integer tenure;
	
	@ApiModelProperty(value = "Coleteral Details")
	private String collateralDetails;
	
	@ApiModelProperty(value = "Status of the Loan Application")
	private String status;

}
