package com.cts.training.collateralwebportal.model;

public enum CollateralType {
	REAL_ESTATE, CASH_DEPOSIT
}
