package com.cts.training.collateralwebportal.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.training.collateralwebportal.feign.AuthClient;
import com.cts.training.collateralwebportal.feign.LoanManagementClient;
import com.cts.training.collateralwebportal.model.CustomerLoan;
import com.cts.training.collateralwebportal.model.CustomerLoanDto;
import com.cts.training.collateralwebportal.model.LoanApplication;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;



@Controller
@Slf4j
public class CustomerLoanController {
	
	@Autowired
	private LoanManagementClient loanClient;
	
	@Autowired
	private AuthClient authClient;
	
	
	
	   @RequestMapping(value = "/customerloan", method = RequestMethod.GET)
       public String show(@ModelAttribute("customloan")CustomerLoanDto customloan,ModelMap model) {
           return "customerloan";
       }

  
    
    @RequestMapping(value = "/customerloan", method = RequestMethod.POST)
       public String submitLoan(@Valid @ModelAttribute("customloan")CustomerLoanDto customloan, 
         BindingResult result, ModelMap model,HttpServletRequest request) {
          
           if (result.hasErrors()) {
               model.put("errorMessage", "Invalid Customer Loan Details!");
               return "customerloan";
           }
           String token = "Bearer "+(String) request.getSession().getAttribute("token");
           CustomerLoan loan=null;
          
		    try {
			loan=loanClient.getLoanDetails(token, customloan.getLoanId(),customloan.getCustomerId());
			 System.out.println("================inside Customer Loan=====================");
			model.addAttribute("loan", loan);
			return "customerloan";
		    }
		    catch (FeignException e) {
				if(e.getMessage().contains("Customer Loan Not found with LoanId")) {
					model.addAttribute("status", "Customer Loan Not found!!");
				}
					return "customerloan";
			}
           
       }
    
    @GetMapping(value = "/applyloan")
    public String applyLoanGet(@ModelAttribute("loanApplication")LoanApplication loanApplication,ModelMap model,HttpServletRequest request) {
    	
    	//for getting session token to get the custId
    	String token=(String)request.getSession().getAttribute("token");
    	int custId=authClient.getCustId(token);
    	model.put("custId", custId);
    	request.setAttribute("custId", custId);
    	
        return "applyLoan";
    }
    
    @PostMapping(value = "/applyloan")
    public String applyLoanPost(@Valid @ModelAttribute("loanApplication")LoanApplication loanApplication,ModelMap model,BindingResult result,HttpServletRequest request) {
    	if(result.hasErrors()) {
    		return "applyLoan";
    	}
    	
    	String token=(String)request.getSession().getAttribute("token");
    	log.info(token);
    	loanClient.applyLoan(token,loanApplication);
        return "successfullyAppliedLoan";
    }
    
    @GetMapping(value = "/getLoanApplicationStatus")
    public String viewLoanCust(ModelMap model,HttpServletRequest request) {
    	String token=(String)request.getSession().getAttribute("token");
    	int custId=authClient.getCustId(token);
    	List<LoanApplication> list= loanClient.getLoanApplicationStatus(token,custId);
    	if(list.size()!=0) {
    		model.put("LoanList", list);
    		return "present";
    	}
    	
    	return "noloanpresent";
    	
    }
    
    @RequestMapping(value="/getAll", method=RequestMethod.GET)
    public String getLoanApplications(ModelMap model) {
    	List<LoanApplication> list=new ArrayList<>();
    	list=loanClient.getAllLoanApplications();
     	if(list.size()!=0) {
     		model.addAttribute("LoanList", list);
     		return "adminloanapplication";
     	}
    	
    	return "noloanpresentadmin";
    }
    
    @GetMapping(value="/approveLoanApplication")
    public String approveLoanApplication(@RequestParam int applicationId) {
    	log.info("approved "+applicationId);
    	loanClient.approveLoanApplication(applicationId);
    	return "redirect:/getAll";
    }
    @GetMapping(value="/rejectLoanApplication")
    public String rejectLoanApplication(@RequestParam int applicationId,HttpServletRequest request) {
    	log.info("rejected "+applicationId);
    	String token=(String)request.getSession().getAttribute("token");
    	loanClient.rejectLoanApplication(token,applicationId);
    	return "redirect:/getAll";
    }
    
    
    @ModelAttribute("collateralList")
    public List<String> getWebFrameworkList()
    {
       List<String> collateralList = new ArrayList<String>();
       collateralList.add("Cash Deposit");
       collateralList.add("Real Estate");
       
       return collateralList;
    }
    
   
    
   
}

